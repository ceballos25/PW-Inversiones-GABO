//Llamamos el dataTables para la tabla de productos
$(document).ready(function(){
    tblInicio = $("#tblEmpleados").DataTable({
        "destroy":true,

  
        //Para cambiar el lenguaje a español
    "language": {
            "lengthMenu": "Mostrar _MENU_ registros",
            "zeroRecords": "No se encontraron resultados",
            "info": "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
            "infoEmpty": "Mostrando registros del 0 al 0 de un total de 0 registros",
            "infoFiltered": "(filtrado de un total de _MAX_ registros)",
            "sSearch": "Buscar:",
            "oPaginate": {
                "sFirst": "Primero",
                "sLast":"Último",
                "sNext":"Siguiente",
                "sPrevious": "Anterior"

                
             },
             "sProcessing":"Procesando...",
        },
    });
  });


//Escondemos el preloader con Jquery, pendiente usar java Script con el SetimeOut, ya que no funcionó y se esconde muy rápido, preguntar al profe

window.onload = function(){
    setTimeout();
   
}

setTimeout(function(){        
    $('#preloader').fadeOut();
    $('body').delay(150).removeClass('esconder__preloader'); 
}, 1000);